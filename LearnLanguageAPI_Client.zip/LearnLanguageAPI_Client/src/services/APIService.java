package services;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

import dto.LessonDto;
import util.APIUtils;

public class APIService {

	/**
	 * Search Lesson
	 *
	 * @return List<LessonDto>
	 */
	public static List<LessonDto> searchLesson() {

		// Result list
		List<LessonDto> lessonDtoList = new ArrayList<LessonDto>();

		try {
			JsonObject result = APIUtils.callSearchAPI();
			JsonArray details = result.get("details").getAsJsonArray();

			Gson gson = new Gson();
			lessonDtoList = gson.fromJson(details, new TypeToken<List<LessonDto>>() {}.getType());

		} catch(Exception ex) {
			ex.printStackTrace();
		}

		return lessonDtoList;
	}
}
