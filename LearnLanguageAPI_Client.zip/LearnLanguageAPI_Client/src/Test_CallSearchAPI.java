import java.util.List;

import dto.LessonDto;
import services.APIService;


public class Test_CallSearchAPI {

	public static void main(String []args) {

		List<LessonDto> lessonDtoList = APIService.searchLesson();
		System.out.println();

	}

}
