package util;

import javax.ws.rs.core.MediaType;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class APIUtils {

	private static final String API_URI = "http://localhost:8080/LearnLanguageAPI/rest/webAPI/search.json";
	
	public static JsonObject callSearchAPI() {
		
		try {
			// Setup URI
			Client client = Client.create();
			WebResource webResource = client.resource(API_URI);
			ClientResponse response = null;
			
			// Create body
			JsonObject body = new JsonObject();
			body.addProperty("table", "T_USER");
			body.addProperty("query", "USER_ID > 1");
			
			// Call SearchAPI
			response = webResource
					.accept(MediaType.APPLICATION_JSON)
					.type(MediaType.APPLICATION_JSON)
					.post(ClientResponse.class, body.toString());
			String strJson = response.getEntity(String.class);
			
			// Return value
			JsonParser jsonParser = new JsonParser();
			return (JsonObject) jsonParser.parse(strJson);
			
		} catch(Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}
	
}
