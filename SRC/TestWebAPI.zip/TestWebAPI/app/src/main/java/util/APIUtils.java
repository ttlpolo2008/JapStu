package util;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.ini4j.Ini;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class APIUtils {

	public static String apiUri;

	/**
	 * Read Ini File
	 * @return
	 */
	private static Boolean readIniFile() {
		if (!StringUtil.isNullOrEmpty(apiUri)) {
			return true;
		}

		try {
			apiUri = "http://192.168.1.44:8080/LearnLanguageAPI/rest/%s/%s.json";
//			Ini iniFile = new Ini(new FileInputStream("C:/LearningLanguage/config.ini"));
//			if (iniFile != null) {
//				apiUri = iniFile.get("API", "API_URI");
//			}
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return false;
	}

	public static JsonObject callSearchAPI(String uri, String api, JsonObject body) {

		try {
			// Read ini file
			if (!readIniFile()) {
				return null;
			}

			// Setup URI
			URL url = new URL(String.format(apiUri, uri, api));
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();

			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-type", "application/json");
			conn.setRequestProperty( "Accept", "application/json" );
			conn.setDoOutput(true);

			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(body.toString());
			writer.flush();

			// Call SearchAPI
			String line;
			String strJson = "";
			BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			while ((line = reader.readLine()) != null) {
				strJson += line;
			}

			// Return value
			JsonParser jsonParser = new JsonParser();
			return (JsonObject) jsonParser.parse(strJson);

		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

}
