package services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import dao.CommonDAO;
import dto.ExerciseDto;

public class ExerciseService {

	/**
	 * Count Exercise by lessonId
	 *
	 * @param lessonId
	 * @return Long
	 */
	public static Long countExercise(Long lessonId) {

		// if [lessonId = null], return 0
		if (lessonId == null) {
			return new Long(0);
		}

		// Get DAO
		Connection conn = CommonDAO.getDAO();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			// Create SQL
			StringBuffer sqlQuery = new StringBuffer();
			sqlQuery.append(" SELECT \n");
			sqlQuery.append("   COUNT(*) AS CNT \n");
			sqlQuery.append(" FROM \n");
			sqlQuery.append("   T_EXERCISE \n");
			sqlQuery.append(" WHERE \n");
			sqlQuery.append("       LESSON_ID = ? \n");

			// Create Statement
			stmt = conn.prepareStatement(sqlQuery.toString());

			// Add condition
			stmt.setLong(1, lessonId);

			// Execute query
			rs = stmt.executeQuery();
			if (rs.next()) {
				return rs.getLong("CNT");
			}

		} catch(Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
			} catch (Exception ex) {
			}
		}

		return new Long(0);
	}

	/**
	 * Search Exercise
	 *
	 * @param lessonId
	 * @return List<ExerciseDto>
	 */
	public static List<ExerciseDto> searchExercise(Long lessonId) {

		// Result list
		List<ExerciseDto> exerciseDtoList = new ArrayList<ExerciseDto>();

		// Get DAO
		Connection conn = CommonDAO.getDAO();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			// Create SQL
			StringBuffer sqlQuery = new StringBuffer();
			sqlQuery.append(" SELECT \n");
			sqlQuery.append("   T2.EXERCISE_ID \n");
			sqlQuery.append("  ,T2.LESSON_ID \n");
			sqlQuery.append("  ,T2.QUESTION_TYPE \n");
			sqlQuery.append("  ,T2.QUESTION_CONTENT \n");
			sqlQuery.append("  ,T2.QUESTION_CONTENT_FILE \n");
			sqlQuery.append("  ,T2.MARK \n");
			sqlQuery.append("  ,T2.TIME \n");
			sqlQuery.append("  ,T2.ANSWER_CHOOSE \n");
			sqlQuery.append("  ,T2.ANSWER_1 \n");
			sqlQuery.append("  ,T2.ANSWER_2 \n");
			sqlQuery.append("  ,T2.ANSWER_3 \n");
			sqlQuery.append("  ,T2.ANSWER_4 \n");
			sqlQuery.append("  ,T2.ANSWER_5 \n");
			sqlQuery.append(" FROM \n");
			sqlQuery.append("   T_LESSON T1 \n");
			sqlQuery.append("  ,T_EXERCISE T2 \n");
			sqlQuery.append(" WHERE \n");
			sqlQuery.append("       1 = 1 \n");
			sqlQuery.append("   AND T1.LESSON_ID = T2.LESSON_ID \n");
			sqlQuery.append("   AND T1.LESSON_ID = ? \n");
			sqlQuery.append(" ORDER BY \n");
			sqlQuery.append("   T2.EXERCISE_ID \n");

			// Create Statement
			stmt = conn.prepareStatement(sqlQuery.toString());

			// Add condition
			stmt.setLong(1, lessonId);

			// Execute query
			rs = stmt.executeQuery();
			while (rs.next()) {
				// Edit Dto
				ExerciseDto exerciseDto = new ExerciseDto();
				exerciseDto.setExerciseId(rs.getLong("EXERCISE_ID"));
				exerciseDto.setLessonId(rs.getLong("LESSON_ID"));
				exerciseDto.setQuestionType(rs.getString("QUESTION_TYPE"));
				exerciseDto.setQuestionContent(rs.getString("QUESTION_CONTENT"));
				exerciseDto.setQuestionContentFile(rs.getString("QUESTION_CONTENT_FILE"));
				exerciseDto.setMark(rs.getInt("MARK"));
				exerciseDto.setTime(rs.getInt("TIME"));
				exerciseDto.setAnswerChoose(rs.getString("ANSWER_CHOOSE"));
				exerciseDto.setAnswer1(rs.getString("ANSWER_1"));
				exerciseDto.setAnswer2(rs.getString("ANSWER_2"));
				exerciseDto.setAnswer3(rs.getString("ANSWER_3"));
				exerciseDto.setAnswer4(rs.getString("ANSWER_4"));
				exerciseDto.setAnswer5(rs.getString("ANSWER_5"));

				// Add Dto to List
				exerciseDtoList.add(exerciseDto);
			}

		} catch(Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (stmt != null) {
					stmt.close();
				}
			} catch (Exception ex) {
			}
		}

		return exerciseDtoList;
	}

	/**
	 * Register all Exercise
	 *
	 * @param exerciseDtoList
	 * @param deletedList
	 * @param lessonId
	 * @return Boolean True:Success / False:Error
	 */
	public static Boolean registerAll(List<ExerciseDto> exerciseDtoList,
									  List<Long> deletedList,
									  Long lessonId) {

		// Get DAO
		Connection conn = CommonDAO.getDAO();
		try {
			// Register Data
			Integer orderIndex = 1;
			for (ExerciseDto exerciseDto : exerciseDtoList) {

				if (exerciseDto.getExerciseId() == null) {
					// Register new data
					exerciseDto.setLessonId(lessonId);
					if (!ExerciseService.insertExercise(exerciseDto)) {
						conn.rollback();
						return false;
					}

				} else if (exerciseDto.getIsChange()) {
					// Update data
					if (!ExerciseService.updateExercise(exerciseDto)) {
						conn.rollback();
						return false;
					}

				}

				orderIndex++;
			}

			// Delete data
			for (Long exerciseId : deletedList) {
				// Delete data
				if (!ExerciseService.deleteExercise(exerciseId)) {
					conn.rollback();
					return false;
				}
			}

			// Commit Transaction
			conn.commit();

			return true;

		} catch (Exception ex) {
			ex.printStackTrace();
			try {
				// Rollback Transaction
				if (conn != null) {
					conn.rollback();
				}
			} catch(Exception ex1) {
			}
		}

		return false;
	}

	/**
	 * Insert Exercise
	 *
	 * @param exerciseDto
	 * @return Boolean True:Success / False:Fail
	 */
	public static Boolean insertExercise(ExerciseDto exerciseDto) {

		// if [exerciseDto = null], return false
		if (exerciseDto == null) {
			return false;
		}

		// Get DAO
		Connection conn = CommonDAO.getDAO();
		try {
			// Create SQL
			StringBuffer sqlQuery = new StringBuffer();
			sqlQuery.append(" INSERT INTO `T_EXERCISE` \n");
			sqlQuery.append("   ( \n");
			sqlQuery.append("     `LESSON_ID` \n");
			sqlQuery.append("    ,`QUESTION_TYPE` \n");
			sqlQuery.append("    ,`QUESTION_CONTENT` \n");
			sqlQuery.append("    ,`QUESTION_CONTENT_FILE` \n");
			sqlQuery.append("    ,`MARK` \n");
			sqlQuery.append("    ,`TIME` \n");
			sqlQuery.append("    ,`ANSWER_CHOOSE` \n");
			sqlQuery.append("    ,`ANSWER_1` \n");
			sqlQuery.append("    ,`ANSWER_2` \n");
			sqlQuery.append("    ,`ANSWER_3` \n");
			sqlQuery.append("    ,`ANSWER_4` \n");
			sqlQuery.append("    ,`ANSWER_5` \n");
			sqlQuery.append("   ) \n");
			sqlQuery.append(" VALUES \n");
			sqlQuery.append("   ( \n");
			sqlQuery.append("     ? \n");
			sqlQuery.append("    ,? \n");
			sqlQuery.append("    ,? \n");
			sqlQuery.append("    ,? \n");
			sqlQuery.append("    ,? \n");
			sqlQuery.append("    ,? \n");
			sqlQuery.append("    ,? \n");
			sqlQuery.append("    ,? \n");
			sqlQuery.append("    ,? \n");
			sqlQuery.append("    ,? \n");
			sqlQuery.append("    ,? \n");
			sqlQuery.append("    ,? \n");
			sqlQuery.append("   ) \n");

			// Create Statement
			PreparedStatement stmt = conn.prepareStatement(sqlQuery.toString());

			// Edit parameter
			stmt.setLong(1, exerciseDto.getLessonId());
			stmt.setString(2, exerciseDto.getQuestionType());
			stmt.setString(3, exerciseDto.getQuestionContent());
			stmt.setString(4, exerciseDto.getQuestionContentFile());
			stmt.setInt(5, exerciseDto.getMark());
			stmt.setInt(6, exerciseDto.getTime());
			stmt.setString(7, exerciseDto.getAnswerChoose());
			stmt.setString(8, exerciseDto.getAnswer1());
			stmt.setString(9, exerciseDto.getAnswer2());
			stmt.setString(10, exerciseDto.getAnswer3());
			stmt.setString(11, exerciseDto.getAnswer4());
			stmt.setString(12, exerciseDto.getAnswer5());

			// Execute SQL
			int cnt = stmt.executeUpdate();
			if (cnt > 0) {
				return true;
			}

		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return false;
	}

	/**
	 * Update Exercise
	 *
	 * @param exerciseDto
	 * @return Boolean True:Success / False:Fail
	 */
	public static Boolean updateExercise(ExerciseDto exerciseDto) {

		// if [exerciseDto = null] or [exerciseId = null], return false
		if (exerciseDto == null || exerciseDto.getExerciseId() == null) {
			return false;
		}

		// Get DAO
		Connection conn = CommonDAO.getDAO();
		try {
			// Create SQL
			StringBuffer sqlQuery = new StringBuffer();
			sqlQuery.append(" UPDATE `T_EXERCISE` \n");
			sqlQuery.append(" SET \n");
			sqlQuery.append("     `QUESTION_TYPE` = ? \n");
			sqlQuery.append("    ,`QUESTION_CONTENT` = ? \n");
			sqlQuery.append("    ,`QUESTION_CONTENT_FILE` = ? \n");
			sqlQuery.append("    ,`MARK` = ? \n");
			sqlQuery.append("    ,`TIME` = ? \n");
			sqlQuery.append("    ,`ANSWER_CHOOSE` = ? \n");
			sqlQuery.append("    ,`ANSWER_1` = ? \n");
			sqlQuery.append("    ,`ANSWER_2` = ? \n");
			sqlQuery.append("    ,`ANSWER_3` = ? \n");
			sqlQuery.append("    ,`ANSWER_4` = ? \n");
			sqlQuery.append("    ,`ANSWER_5` = ? \n");
			sqlQuery.append(" WHERE \n");
			sqlQuery.append("       `EXERCISE_ID` = ? \n");

			// Create Statement
			PreparedStatement stmt = conn.prepareStatement(sqlQuery.toString());

			// Edit parameter
			stmt.setString(1, exerciseDto.getQuestionType());
			stmt.setString(2, exerciseDto.getQuestionContent());
			stmt.setString(3, exerciseDto.getQuestionContentFile());
			stmt.setInt(4, exerciseDto.getMark());
			stmt.setInt(5, exerciseDto.getTime());
			stmt.setString(6, exerciseDto.getAnswerChoose());
			stmt.setString(7, exerciseDto.getAnswer1());
			stmt.setString(8, exerciseDto.getAnswer2());
			stmt.setString(9, exerciseDto.getAnswer3());
			stmt.setString(10, exerciseDto.getAnswer4());
			stmt.setString(11, exerciseDto.getAnswer5());
			stmt.setLong(12, exerciseDto.getExerciseId());

			// Execute SQL
			int cnt = stmt.executeUpdate();
			if (cnt > 0) {
				return true;
			}

		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return false;
	}

	/**
	 * Delete Exercise
	 *
	 * @param exerciseId
	 * @return Boolean True:Success / False:Fail
	 */
	public static Boolean deleteExercise(Long exerciseId) {

		// if [exerciseId = null], return false
		if (exerciseId == null) {
			return false;
		}

		// Get DAO
		Connection conn = CommonDAO.getDAO();
		try {
			// Create SQL
			StringBuffer sqlQuery = new StringBuffer();
			sqlQuery.append(" DELETE FROM `T_EXERCISE` \n");
			sqlQuery.append(" WHERE \n");
			sqlQuery.append("       `EXERCISE_ID` = ? \n");

			// Create Statement
			PreparedStatement stmt = conn.prepareStatement(sqlQuery.toString());

			// Edit parameter
			stmt.setLong(1, exerciseId);

			// Execute SQL
			int cnt = stmt.executeUpdate();
			if (cnt > 0) {
				return true;
			}

		} catch(Exception ex) {
			ex.printStackTrace();
		}
		return false;
	}
}
