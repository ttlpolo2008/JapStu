package enums;

public enum QuestionType {
	CHOOSE_ONE("1"),
	CHOOSE_MANY("2"),
	WRITE("3"),
	LISTEN("4");

	/**
	 * CODE
	 */
	private String code;

	QuestionType(String code) {
		this.code = code;
	}

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
}
