package enums;

public enum MoveType {
	MOVE_TOP,
	MOVE_UP,
	MOVE_DOWN,
	MOVE_LAST
}
