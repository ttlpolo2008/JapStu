package enums;

public enum EditMode {
	NEW,
	UPDATE;
}
