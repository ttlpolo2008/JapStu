package util;

import java.awt.Component;
import java.awt.Container;

public class ComponentUtil {

	/**
	 * Enable/Disable all components.
	 *
	 * @param panel
	 * @param enable
	 */
	public static void enableComponents(Container container, Boolean enable) {
		Component[] components = container.getComponents();
		for (Component component : components) {
			component.setEnabled(enable);
			if (component instanceof Container) {
				enableComponents((Container)component, enable);
			}
		}
	}

}
