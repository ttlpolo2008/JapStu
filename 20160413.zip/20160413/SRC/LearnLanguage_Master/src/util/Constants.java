package util;

public class Constants {

	public static final String MSG_NOT_CHOOSE_ROW = "Please select row.";

	public static final String MSG_CANCEL_CONFIRM = "If you choose [Yes], the editing data will be lost.";

	public static final String MSG_DELETE_CONFIRM = "You are deleting data, are you sure?";
	public static final String MSG_DELETE_FOREIGN_KEY = "This data has been using. You can not delete it.";

	public static final String MSG_REGISTER_CONFIRM = "Regiser data?";
	public static final String MSG_REGISTER_FAIL = "Regiser fail. Someone has changed data, please refresh.";
	public static final String MSG_REGISTER_SUCCESS = "Regiser success.";

}
